$(document).ready(function () {
    $('#nav').load("../templates/nav.html");
});